public class GPSData {
    private String busID;
    private String timestamp;
    private String latitude;
    private String longitude;
    private String speed;

    public DatosGPS(String busID, String timestamp, String latitude, String longitude, String speed) {

    }

    public String getId_autobus() {
        return busID;
    }

    public String getTiempo() {
        return timestamp;
    }

    public double getLatitud() {
        return latitude;
    }

    public double getLongitud() {
        return longitude;
    }

    public String getVelocidad() {
        return speed;
    }

    @Override
    public String toString() {
        return busID + "," + timestamp + "," + latitude + "," + longitude + "," + speed;
    }
}
