import java.io.FileWriter;
import java.time.format.DateTimeFormatter;
import java.util.Random;
import java.time.LocalDateTime;
import java.io.IOException;

public class GenerarDatosGps {

    private static final String[] AUTOBUSES = {"BUS1", "BUS2", "BUS3"};

    private static final String ARCHIVO_DATOS = "localizacion_gps.csv";

    private static final int MINUTOS = 60;

    public static void main(String[] args) {
        try (FileWriter escritor = new FileWriter(ARCHIVO_DATOS)){

            escritor.write("id_autobus,tiempo,latitud,longitud,velocidad\n");

            LocalDateTime inicio = LocalDateTime.of(2025, 4, 21, 9, 0);
            DateTimeFormatter formato = DateTimeFormatter.ISO_LOCAL_DATE_TIME;

            Random random = new Random();

            for (String autobus : AUTOBUSES) {

                double latitud = 20.7689;
                double longitud = 60.4172;

                for (int i = 0; i<MINUTOS; i++) {
                    LocalDateTime momento = inicio.plusMinutes(i);

                    double velocidad = random.nextDouble() * 50;

                    latitud += 0.00005 * (random.nextDouble() - 0.5);
                    longitud += 0.00005 * (random.nextDouble() - 0.5);

                    escritor.write(autobus + "," +
                            momento.format(formato) + "," +
                            String.format("%.6f", latitud) + "," +
                            String.format("%.6f", longitud) + "," +
                            String.format("%.2f", velocidad) + "\n");

                    System.out.println("Datos GPS simulados guardados en " + ARCHIVO_DATOS);
                }
            }
        } catch (Exception e){
            System.out.println("Error");
        }
    }
}
