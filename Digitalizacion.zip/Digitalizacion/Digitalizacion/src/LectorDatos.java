import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class LectorDatos {

    public static ArrayList<GPSData> leerGPSData(String rutaArchivo) {
        ArrayList<GPSData> datos = new ArrayList<>();

        }

    }

