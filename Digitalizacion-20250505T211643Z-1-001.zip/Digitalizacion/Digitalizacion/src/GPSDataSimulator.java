import java.time.LocalDateTime;
import java.util.Random;

public class GPSDataSimulator {

    private static final Random random = new Random();
    private static final double LAT_MIN = 19.0;    // Valor mínimo de latitud (por ejemplo, Ciudad de México)
    private static final double LAT_MAX = 20.0;    // Valor máximo de latitud
    private static final double LON_MIN = -99.5;   // Valor mínimo de longitud
    private static final double LON_MAX = -98.5;   // Valor máximo de longitud
    private static final double MIN_SPEED = 20.0;  // Velocidad mínima en km/h
    private static final double MAX_SPEED = 60.0;  // Velocidad máxima en km/h

    // Simulador para generar los datos GPS
    public static GPSData generateData(int busId) {
        // Generar un timestamp (hora actual)
        LocalDateTime timestamp = LocalDateTime.now();

        // Generar latitud y longitud aleatoria dentro de los límites
        double latitude = LAT_MIN + (LAT_MAX - LAT_MIN) * random.nextDouble();
        double longitude = LON_MIN + (LON_MAX - LON_MIN) * random.nextDouble();

        // Generar una velocidad aleatoria entre el rango definido
        double speed = MIN_SPEED + (MAX_SPEED - MIN_SPEED) * random.nextDouble();

        // Crear un objeto GPSData con los datos generados
        return new GPSData(busId, timestamp, latitude, longitude, speed);
    }

    public static void main(String[] args) {
        // Simulador de tres autobuses durante 60 minutos (1 minuto por intervalo)
        for (int minute = 0; minute < 60; minute++) {
            LocalDateTime currentTime = LocalDateTime.now().minusMinutes(60 - minute);
            System.out.println("Tiempo: " + currentTime);

            // Simular datos para tres autobuses
            for (int busId = 1; busId <= 3; busId++) {
                // Generar datos GPS para cada autobús
                GPSData gpsData = generateData(busId);

                // Mostrar los datos generados (en la consola o en cualquier otro lugar)
                System.out.println(gpsData);
            }

            // Pausar por 1 minuto (simulación realista de intervalos)
            try {
                Thread.sleep(60000);  // 60,000 ms = 1 minuto
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
