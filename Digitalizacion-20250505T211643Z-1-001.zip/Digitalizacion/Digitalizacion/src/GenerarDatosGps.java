import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.Random;

public class GenerarDatosGps {

    public static void main(String[] args) {
        Random random = new Random();
        String fileName = "gps_data.csv";

        try (FileWriter writer = new FileWriter(fileName)) {
            // Escribir la cabecera del CSV
            writer.append("busId,timestamp,latitude,longitude,speed\n");

            // Generar datos para 3 autobuses durante 60 minutos
            for (int minute = 0; minute < 60; minute++) {
                LocalDateTime timestamp = LocalDateTime.now().minusMinutes(60 - minute); // Generamos los timestamps de 60 minutos atrás
                for (int busId = 1; busId <= 3; busId++) {
                    // Simulación de datos GPS
                    double latitude = 19.4326 + random.nextDouble() * 0.01;  // Latitude simulada (aproximadamente en la Ciudad de México)
                    double longitude = -99.1332 + random.nextDouble() * 0.01;  // Longitude simulada
                    double speed = 20 + random.nextDouble() * 50; // Velocidad aleatoria entre 20 y 70 km/h

                    // Crear un objeto GPSData
                    GPSData gpsData = new GPSData(busId, timestamp, latitude, longitude, speed);

                    // Escribir los datos en el archivo CSV
                    writer.append(gpsData.toString()).append("\n");
                }
            }

            System.out.println("Datos generados y guardados en " + fileName);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
