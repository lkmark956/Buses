import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class LectorDatos {

    public static void main(String[] args) {
        String fileName = "gps_data.csv";

        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // Imprimir cada línea del CSV
                System.out.println(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
